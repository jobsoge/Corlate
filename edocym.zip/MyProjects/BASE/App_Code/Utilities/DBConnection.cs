﻿using System;
using System.Configuration;

/// <summary>
/// Summary description for DBConnection
/// </summary>
public class DBConnection
{
	public DBConnection()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static string ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnection"]);
}