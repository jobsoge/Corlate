﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;

/// <summary>
/// Summary description for EmailManager
/// </summary>
public class EmailManager
{
	public EmailManager()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    private static string SmtpServerName = Convert.ToString(ConfigurationManager.AppSettings["SmtpServerName"]);
    private static int SmtpPort = Convert.ToInt32(ConfigurationManager.AppSettings["SmtpPort"]);
    private static string SmtpUsername = Convert.ToString(ConfigurationManager.AppSettings["SmtpUsername"]);
    private static string SmtpPassword = Convert.ToString(ConfigurationManager.AppSettings["SmtpPassword"]);

    public class EmailAttachment
    {

        public EmailAttachment(MemoryStream msData, string attachmentName, AttachmentFormats attachmentFormat)
        {
            this.msData = msData;
            this.attachmentName = attachmentName;
            this.attachmentFormat = attachmentFormat;
        }

        public MemoryStream msData { get; set; }

        public string attachmentName { get; set; }

        public AttachmentFormats attachmentFormat { get; set; }
    }

    public enum AttachmentFormats
    {
        Excel = 1,
        Doc = 2,
        Pdf = 3
    }    

    /// <summary>
    /// send email
    /// </summary>
    /// <param name="fromEmailId"></param>
    /// <param name="emailSubject"></param>
    /// <param name="emailBody"></param>
    /// <param name="toEmailIds"></param>
    /// <param name="ccEmailIds"></param>
    /// <param name="bccEmailIds"></param>
    /// <returns></returns>
    public static bool SendEmail(string fromEmailId, string toEmailIds, string ccEmailIds, string bccEmailIds, string emailSubject, string emailBody)
    {
        if (!string.IsNullOrEmpty(emailBody) && !string.IsNullOrEmpty(toEmailIds))
        {
            MailMessage oMailMessage = new MailMessage();
            SmtpClient oSmtpClient = new SmtpClient();

            ///Getting SMTP host name from web.config
            oSmtpClient.Host = SmtpServerName;
            oSmtpClient.Port = SmtpPort;

            if (!string.IsNullOrEmpty(SmtpUsername) && !string.IsNullOrEmpty(SmtpPassword))
            {
                NetworkCredential nc = new System.Net.NetworkCredential(SmtpUsername, SmtpPassword);
                oSmtpClient.Credentials = nc;
            }

            oSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

            oMailMessage.From = new MailAddress(fromEmailId);
            oMailMessage.To.Add(toEmailIds);

            ///Checking whether to mark CC or not
            if (!string.IsNullOrEmpty(ccEmailIds))
            {
                oMailMessage.CC.Add(ccEmailIds);
            }

            ///Checking whether to mark BCc or not
            if (!string.IsNullOrEmpty(bccEmailIds))
            {
                oMailMessage.Bcc.Add(bccEmailIds);
            }

            oMailMessage.Subject = emailSubject.Trim().Replace("\r", "").Replace("\n", "");
            oMailMessage.Body = emailBody;
            oMailMessage.BodyEncoding = System.Text.Encoding.ASCII;
            oMailMessage.IsBodyHtml = true;
            oMailMessage.Priority = (System.Net.Mail.MailPriority)System.Net.Mail.MailPriority.Normal;

            ///Sending Mail Message
            oSmtpClient.Send(oMailMessage);
            return true;
        }
        else
        {
            return false;
        }
    }

    /// <summary>
    /// send email with a single attachment
    /// </summary>
    /// <param name="fromEmailId"></param>
    /// <param name="emailSubject"></param>
    /// <param name="emailBody"></param>
    /// <param name="toEmailIds"></param>
    /// <param name="ccEmailIds"></param>
    /// <param name="bccEmailIds"></param>
    /// <param name="mStream"></param>
    /// <param name="attachmentName"></param>
    /// <param name="attachmentFormat"></param>
    /// <returns></returns>
    public static bool SendEmailWithAttachment(string fromEmailId, string toEmailIds, string ccEmailIds, string bccEmailIds, string emailSubject, string emailBody, MemoryStream mStream, string attachmentName, AttachmentFormats attachmentFormat)
    {
        if (!string.IsNullOrEmpty(emailBody) && !string.IsNullOrEmpty(toEmailIds))
        {
            MailMessage oMailMessage = new MailMessage();
            SmtpClient oSmtpClient = new SmtpClient();

            ///Getting SMTP host name from web.config
            oSmtpClient.Host = SmtpServerName;
            oSmtpClient.Port = SmtpPort;

            if (!string.IsNullOrEmpty(SmtpUsername) && !string.IsNullOrEmpty(SmtpPassword))
            {
                NetworkCredential nc = new System.Net.NetworkCredential(SmtpUsername, SmtpPassword);
                oSmtpClient.Credentials = nc;
            }

            oSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

            oMailMessage.From = new MailAddress(fromEmailId);
            oMailMessage.To.Add(toEmailIds);

            ///Checking whether to mark CC or not
            if (!string.IsNullOrEmpty(ccEmailIds))
            {
                oMailMessage.CC.Add(ccEmailIds);
            }

            ///Checking whether to mark BCc or not
            if (!string.IsNullOrEmpty(bccEmailIds))
            {
                oMailMessage.Bcc.Add(bccEmailIds);
            }

            oMailMessage.Subject = emailSubject.Trim().Replace("\r", "").Replace("\n", "");
            oMailMessage.Body = emailBody;
            oMailMessage.BodyEncoding = System.Text.Encoding.ASCII;
            oMailMessage.IsBodyHtml = true;
            oMailMessage.Priority = (System.Net.Mail.MailPriority)System.Net.Mail.MailPriority.Normal;           

            //add attachment
            mStream.Position = 0;
            oMailMessage.Attachments.Add(new Attachment(mStream, SetAttachmentFormat(attachmentName, attachmentFormat)));

            ///Sending Mail Message
            oSmtpClient.Send(oMailMessage);
            return true;
        }
        else
        {
            return false;
        }        
    }

    /// <summary>
    /// send email with a multiple attachments
    /// </summary>
    /// <param name="fromEmailId"></param>
    /// <param name="emailSubject"></param>
    /// <param name="emailBody"></param>
    /// <param name="toEmailIds"></param>
    /// <param name="ccEmailIds"></param>
    /// <param name="bccEmailIds"></param>
    /// <param name="lstAttachments"></param>
    /// <returns></returns>
    public static bool SendEmailWithAttachments(string fromEmailId, string toEmailIds, string ccEmailIds, string bccEmailIds, string emailSubject, string emailBody, List<EmailAttachment> lstAttachments)
        {
            if (!string.IsNullOrEmpty(emailBody) && !string.IsNullOrEmpty(toEmailIds))
            {
                MailMessage oMailMessage = new MailMessage();
                SmtpClient oSmtpClient = new SmtpClient();

                ///Getting SMTP host name from web.config
                oSmtpClient.Host = SmtpServerName;
                oSmtpClient.Port = SmtpPort;

                if (!string.IsNullOrEmpty(SmtpUsername) && !string.IsNullOrEmpty(SmtpPassword))
                {
                    NetworkCredential nc = new System.Net.NetworkCredential(SmtpUsername, SmtpPassword);
                    oSmtpClient.Credentials = nc;
                }

                oSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;

                oMailMessage.From = new MailAddress(fromEmailId);
                oMailMessage.To.Add(toEmailIds);

                ///Checking whether to mark CC or not
                if (!string.IsNullOrEmpty(ccEmailIds))
                {
                    oMailMessage.CC.Add(ccEmailIds);
                }

                ///Checking whether to mark BCc or not
                if (!string.IsNullOrEmpty(bccEmailIds))
                {
                    oMailMessage.Bcc.Add(bccEmailIds);
                }

                oMailMessage.Subject = emailSubject.Trim().Replace("\r", "").Replace("\n", "");
                oMailMessage.Body = emailBody;
                oMailMessage.BodyEncoding = System.Text.Encoding.ASCII;
                oMailMessage.IsBodyHtml = true;
                oMailMessage.Priority = (System.Net.Mail.MailPriority)System.Net.Mail.MailPriority.Normal;

                //add attachments
                int AttachmentNumber = 1;
                string AttachmentName = string.Empty;
                foreach (EmailAttachment obj in lstAttachments)
                {
                    if (obj.msData != null)
                    {
                        obj.msData.Position = 0;
                        if(string.IsNullOrEmpty(obj.attachmentName))
                        {
                            AttachmentName = "File_" + AttachmentNumber;
                            AttachmentNumber++;
                        }
                        else
                        {
                            AttachmentName = obj.attachmentName;
                        }
                        oMailMessage.Attachments.Add(new Attachment(obj.msData, SetAttachmentFormat(AttachmentName, obj.attachmentFormat)));
                    }
                }

                ///Sending Mail Message
                oSmtpClient.Send(oMailMessage);
                return true;
            }
            else
            {
                return false;
            }
        }

    /// <summary>
    /// check if the attachment has proper format
    /// </summary>
    /// <param name="attachmentName"></param>
    /// <returns></returns>
    private static string SetAttachmentFormat(string attachmentName, AttachmentFormats attachmentFormat )
    {
        string ExpectedAttachmentFormat = string.Empty;

        switch (attachmentFormat)
        {
            case AttachmentFormats.Excel:
                ExpectedAttachmentFormat = ".xlsx";
                break;
            case AttachmentFormats.Pdf:
                ExpectedAttachmentFormat = ".pdf";
                break;
        }

        if (!attachmentName.EndsWith(ExpectedAttachmentFormat))
        {
            attachmentName += ExpectedAttachmentFormat;
        }
        return attachmentName;
    }

    #region EXAMPLES
    /*-----------------HOW TO ADD MULTIPLE ATTACHMENTS-------------------*/
     //MemoryStream MsData = null;
     //string AttachmentName = string.Empty;
     //List<EmailAttachment> lstAttachments = new List<EmailAttachment>();

     //MsData = DataTableToMemoryStream(dt1);
     //AttachmentName = "DT1.xlsx";
     //lstAttachments.Add(new EmailAttachment(MsData, AttachmentName, EmailAttachment.AttachmentFormats.Excel));

     //MsData = DataTableToMemoryStream(dt2);
     //AttachmentName = "DT2.xlsx";
     //lstAttachments.Add(new EmailAttachment(MsData, AttachmentName, EmailAttachment.AttachmentFormats.Excel));
    #endregion
}

