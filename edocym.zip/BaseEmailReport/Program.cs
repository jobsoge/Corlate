﻿using System;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;

class Program
{
    #region VARIABLES
    private static string isCustomReport = Convert.ToString(ConfigurationManager.AppSettings["IsCustomReport"]);
    private static string reportTitle = Convert.ToString(ConfigurationManager.AppSettings["ReportTitle"]);
    private static DateTime? fromDate;
    private static DateTime toDate;
    #endregion

    static void Main(string[] args)
    {
        try
        {
            if (isCustomReport == "1")
            {
                try
                {
                    fromDate = Convert.ToDateTime(ConfigurationManager.AppSettings["FromDate"]);
                    toDate = Convert.ToDateTime(ConfigurationManager.AppSettings["ToDate"]);

                    if (toDate < fromDate)
                    {
                        Console.WriteLine("The ToDate should be greater than or equal to FromDate");
                        Console.ReadKey();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.ReadKey();
                }
            }
            else
            {
                //to get data until previous day
                fromDate = null;
                toDate = DateTime.Now.AddDays(-1);
            }

            Console.WriteLine("Getting applications data...");
            DataTable dtReport = ReportDB.GetReportData(fromDate, toDate);

            if (dtReport != null && dtReport.Rows.Count > 0)
            {
                Console.WriteLine("Generating report...");
                SendReportEmail(dtReport, fromDate, toDate);
            }
            else
                Console.WriteLine("No records found for the provided date range");

            Console.WriteLine("PROCESS COMPLETE");
        }
        catch (Exception ex)
        {
            LogManager.SaveLog(GlobalConstants.MODULE_NAME, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name, ex, LogManager.LogTypes.Error, string.Empty);
            EmailManager.SendEmail(Convert.ToString(ConfigurationManager.AppSettings["EmailFrom"]), Convert.ToString(ConfigurationManager.AppSettings["AdminEmailTo"]), string.Empty, string.Empty, Convert.ToString(ConfigurationManager.AppSettings["EmailSubjectForError"]), FrameEmailContent(true, fromDate, toDate, ex.Message));
        }
    }

    #region METHODS

    /// <summary>
    /// frame email content
    /// </summary>
    /// <param name="isError"></param>
    /// <param name="fromDate"></param>
    /// <param name="toDate"></param>
    /// <param name="errorMessage"></param>
    private static string FrameEmailContent(bool isError, DateTime? fromDate, DateTime toDate, string errorMessage)
    {
        StringBuilder sb = new StringBuilder(string.Empty);

        if (isError)
        {
            sb.Append("Hello User,<br /><br />");

            if (fromDate == null)
                sb.Append("A problem occurred when generating " + reportTitle + " report for data received until " + toDate.ToString("dd-MMM-yyyy"));
            else if (fromDate.GetValueOrDefault().ToShortDateString() == toDate.ToShortDateString())
                sb.Append("A problem occurred when generating " + reportTitle + " report for data received on " + toDate.ToString("dd-MMM-yyyy"));
            else
                sb.Append("A problem occurred when generating " + reportTitle + " report for data received between " + fromDate.Value.ToString("dd-MMM-yyyy") + " and " + toDate.ToString("dd-MMM-yyyy"));

            sb.Append("<br /><br />");
            sb.Append("ERROR : " + errorMessage);
            sb.Append("<br /><br /><br />Regards,<br />Website team<br /><a href=\"www.vodafone.in\">www.vodafone.in</a><br /><br />Note: This is an auto-generated email. Please do not reply directly to this email.");
        }
        else
        {
            sb.Append("Hello User,<br /><br />");            

            if (fromDate == null)
                sb.Append("Please find the attached report for " + reportTitle + " data, received until " + toDate.ToString("dd-MMM-yyyy"));
            else if (fromDate.GetValueOrDefault().ToShortDateString() == toDate.ToShortDateString())
                sb.Append("Please find the attached report for " + reportTitle + " data, received on " + toDate.ToString("dd-MMM-yyyy"));
            else
                sb.Append("Please find the attached report for " + reportTitle + " data, received between " + fromDate.Value.ToString("dd-MMM-yyyy") + " and " + toDate.ToString("dd-MMM-yyyy"));

            sb.Append("<br /><br /><br />Regards,<br />Website team<br /><a href=\"www.vodafone.in\">www.vodafone.in</a><br /><br />Note: This is an auto-generated email. Please do not reply directly to this email.");
        }

        return sb.ToString();
    }

    /// <summary>
    /// send email with attached report
    /// </summary>
    /// <param name="dtReport"></param>
    /// <param name="fromDate"></param>
    /// <param name="toDate"></param>
    private static void SendReportEmail(DataTable dtReport, DateTime? fromDate, DateTime toDate)
    {
        MemoryStream mstream = Common.DataTableToMemoryStream(dtReport);

        if (mstream != null)
        {
            string emailContent = FrameEmailContent(false, fromDate, toDate, string.Empty);

            if (!string.IsNullOrEmpty(emailContent))
            {
                string emailTo = Convert.ToString(ConfigurationManager.AppSettings["EmailTo"]);

                if (!string.IsNullOrEmpty(emailTo))
                {
                    string emailFrom = Convert.ToString(ConfigurationManager.AppSettings["EmailFrom"]);
                    string emailCc = Convert.ToString(ConfigurationManager.AppSettings["EmailCc"]);
                    string emailBcc = Convert.ToString(ConfigurationManager.AppSettings["EmailBcc"]);
                    string emailSubject = Convert.ToString(ConfigurationManager.AppSettings["EmailSubject"]);
                    string attachmentName = Convert.ToString(ConfigurationManager.AppSettings["AttachmentName"]);

                    if (!string.IsNullOrEmpty(emailSubject))
                    {
                        if (fromDate == null)
                            emailSubject = string.Format(emailSubject, "until " + toDate.ToString("dd-MMM-yyyy"));
                        else if (fromDate.GetValueOrDefault().ToShortDateString() == toDate.ToShortDateString())
                            emailSubject = string.Format(emailSubject, "on " + toDate.ToString("dd-MMM-yyyy"));
                        else
                            emailSubject = string.Format(emailSubject, "between " + fromDate.Value.ToString("dd-MMM-yyyy") + " and " + toDate.ToString("dd-MMM-yyyy"));
                    }

                    attachmentName = (attachmentName.EndsWith("_") ? attachmentName : attachmentName + "_") + DateTime.Now.ToString("yyyyMMdd");

                    Console.WriteLine("Sending email...");

                    if (!EmailManager.SendEmailWithAttachment(emailFrom, emailTo, emailCc, emailBcc, emailSubject, emailContent, mstream, attachmentName, EmailManager.AttachmentFormats.Excel))
                        LogManager.SaveLog(GlobalConstants.MODULE_NAME, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name, null, LogManager.LogTypes.Message, "Could not send email");
                }
                else
                    LogManager.SaveLog(GlobalConstants.MODULE_NAME, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name, null, LogManager.LogTypes.Message, "'To Email' address not available");
            }
            else
                LogManager.SaveLog(GlobalConstants.MODULE_NAME, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name, null, LogManager.LogTypes.Message, "Could not create email content");
        }
        else
            LogManager.SaveLog(GlobalConstants.MODULE_NAME, System.Reflection.MethodBase.GetCurrentMethod().ReflectedType.Name + "." + System.Reflection.MethodBase.GetCurrentMethod().Name, null, LogManager.LogTypes.Message, "Could not create attachment");
    }

    #endregion
}
