﻿using Microsoft.ApplicationBlocks.Data;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public class ReportDB : DBConnection
{
    /// <summary>
    /// get report data by date range
    /// </summary>
    /// <param name="fromdate"></param>
    /// <param name="toDate"></param>
    /// <returns></returns>
    public static DataSet GetReportData(DateTime? fromdate, DateTime toDate)
    {
        DataSet dsReport = new DataSet();
        SqlDataAdapter da;

        using (SqlConnection con = new SqlConnection(ConnectionString))
        {
            using (SqlCommand cmd = new SqlCommand("usp_GetSupernetFeedbackReport", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FromDate", fromdate);
                cmd.Parameters.AddWithValue("@ToDate", toDate);
                cmd.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["SQLCommandTimeOut"]);
                con.Open();
                da = new SqlDataAdapter(cmd);
                da.Fill(dsReport);
            }
        }

        return dsReport;
    }

    /// <summary>
    /// save audit
    /// </summary>
    public static void SaveSupernetFeedbackReportAudit(ReportAudit objAudit)
    {
        SqlParameter[] sqlParams = new SqlParameter[5];
        sqlParams[0] = new SqlParameter("@FKCircleId", objAudit.FKCircleId);
        sqlParams[1] = new SqlParameter("@DataFromDate", objAudit.DataFromDate);
        sqlParams[2] = new SqlParameter("@DataToDate", objAudit.DataToDate);
        sqlParams[3] = new SqlParameter("@IsDataAvailable", objAudit.IsDataAvailable);
        sqlParams[4] = new SqlParameter("@IsEmailSent", objAudit.IsEmailSent);

        SqlHelper.ExecuteDataset(ConnectionString, CommandType.StoredProcedure, "usp_SaveSupernetFeedbackReportAudit", sqlParams);
    }
}
