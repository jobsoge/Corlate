﻿using CodeStack.Components.Export;
using OfficeOpenXml.Style;
using System.Data;
using System.Drawing;
using System.IO;

public class Common
{
    public static MemoryStream DataTableToMemoryStream(DataTable dtData)
    {
        ExportExcel obj = new ExportExcel();
        obj.showGridLines = true;
        obj.headerStyle = new CodeStack.Components.Export.Style(Color.SlateGray, Color.White, Color.Black, ExcelBorderStyle.Thin);
        MemoryStream ms = obj.GenerateDocument(dtData);
        return ms;
    }
}
