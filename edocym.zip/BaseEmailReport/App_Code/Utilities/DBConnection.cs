﻿using System;
using System.Configuration;

public class DBConnection
{
    public static string ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnection"]);
}
