﻿
public class GlobalConstants
{
    public static string MODULE_NAME = "SupernetReport";
}
