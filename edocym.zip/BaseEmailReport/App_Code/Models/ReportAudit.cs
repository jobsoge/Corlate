﻿using System;

public class ReportAudit
{
    public int FKCircleId { get; set; }
    public DateTime? DataFromDate { get; set; }
    public DateTime? DataToDate { get; set; }
    public bool IsDataAvailable { get; set; }
    public bool IsEmailSent { get; set; }
}