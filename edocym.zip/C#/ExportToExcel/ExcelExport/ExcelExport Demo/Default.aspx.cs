﻿using System;
using System.Data;
using System.IO;
using System.Web;
using OfficeOpenXml.Style;
using OfficeOpenXml.Table;
using CodeStack.Components.Export;

public partial class _Default : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        ClearAll();
        BindGrid();
    }
    #endregion

    #region Events
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            ClearAll();

            ExportExcel obj = new ExportExcel();
            obj.sheetName = "Employee Details";
            obj.applyFilters = true;
            // obj.logoPath = @"D:\Answers.xlsx";
            obj.logoPath = Server.MapPath(@"~\Images\Logo.jpg");
            obj.showGridLines = true;
            obj.freezeRows = 2;
            obj.freezeColumns = 3;
            obj.password = "pnws@123";
            obj.dateTimeFormat = "DD-MMM-YYYY";

            obj.tableStyle = TableStyles.Medium1;

            //obj.headerStyle = new Style(System.Drawing.Color.Aqua, System.Drawing.Color.DarkViolet, System.Drawing.Color.Yellow, ExcelBorderStyle.Medium);
            //obj.itemStyle = new Style(System.Drawing.Color.White, System.Drawing.Color.Black, System.Drawing.Color.Black, ExcelBorderStyle.Thin);
            //obj.alternateItemStyle = new Style(System.Drawing.Color.White, System.Drawing.Color.Black, System.Drawing.Color.Black, ExcelBorderStyle.Thin);

            MemoryStream ms = obj.GenerateDocument(((DataSet)GetDataset()).Tables[0]);
            ExporttoFile(ms, "Employee");

        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message.ToString();
        }
    }

    #endregion

    #region Private Methods

    private DataSet GetDataset()
    {
        DataTable data = new DataTable();

        #region Column

        data.Columns.Add("EMPCODE", typeof(string));
        data.Columns.Add("Firstname", typeof(string));
        data.Columns.Add("Department", typeof(string));
        data.Columns.Add("Gender", typeof(string));
        data.Columns.Add("AGE", typeof(int));
        data.Columns.Add("Mobile", typeof(double));
        data.Columns.Add("Email", typeof(string));
        data.Columns.Add("DOJ", typeof(DateTime));
        data.Columns.Add("City", typeof(string));
        data.Columns.Add("State", typeof(string));
        data.Columns.Add("Country", typeof(string));
        data.Columns.Add("Religion", typeof(string));

        #endregion

        #region Dummy Data
        data.Rows.Add(new object[] { "D03382", "Sunita Sundaran", "HR", "Female", 25, 9966998981, "sunitas@pennywise.org", "2012-04-02 00:00:00.000", "Chennai", "TamilNadu", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03140", "S Praveen Kumar", "DotNet", "Male", 34, 9966998982, "praveen@pennywise.org", "2006-03-23 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03201", "Srikaracharya Vakranambi", "DotNet", "Male", 30, 9966998983, "srikaracharya@pennywise.org", "2008-01-16 00:00:00.000", "Nizamabad", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03226", "Anil Kumar Nammi", "DotNet", "Male", 31, 9966998984, "anilkumar@pennywise.org", "2008-07-03 00:00:00.000", "Vizag", "Andhra Pradesh", "India", "Muslim" });
        data.Rows.Add(new object[] { "D03255", "Narendra Mohan Sigurkota", "DotNet", "Male", 30, 9966998985, "narendra@pennywise.org", "2009-11-24 00:00:00.000", "Srikakulam", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03330", "Suman Jangiti", "DotNet", "Male", 27, 9966998986, "suman@pennywise.org", "2011-05-16 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03355", "Praveen Reddy Manukonda", "SharePoint", "Male", 26, 9966998987, "praveenm@pennywise.org", "2011-10-03 00:00:00.000", "Vijaywada", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03421", "Hari Prasad Kotha", "SharePoint", "Male", 24, 9966998995, "harik@pennywise.org", "2013-03-01 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03371", "Chandra Shekar Reddy Dundra", "DotNet", "Male", 28, 9966998988, "chandrashekard@pennywise.org", "2011-11-22 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03372", "Jayavardhan Sarawathula", "DotNet", "Male", 28, 9966998989, "jayavardhans@pennywise.org", "2011-11-23 00:00:00.000", "Vizag", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03285", "Frederick Nelaturi", "Customer Services", "Male", 33, 9966998990, "frederick@pennywise.org", "2010-10-04 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Christian" });
        data.Rows.Add(new object[] { "D03098", "Vigneshwar Falaram", "Design", "Male", 34, 9966998991, "vigneshwar@pennywise.org", "2005-03-01 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03147", "Chintala Babu Sri Harsha", "ORM", "Male", 36, 9966998992, "sriharsha@pennywise.org", "2006-05-03 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03254", "Kiran Chand Gangala", "ORM", "Male", 32, 9966998993, "kiranchand@pennywise.org", "2009-09-16 00:00:00.000", "Bangalore", "Karnataka", "India", "Hindu" });
        data.Rows.Add(new object[] { "D03291", "Praveen Kumar Bellamkonda", "ORM", "Male", 30, 9966998994, "praveenb@pennywise.org", "2010-10-04 00:00:00.000", "Hyderabad", "Andhra Pradesh", "India", "Hindu" });
        #endregion
        DataSet ds = new DataSet();
        ds.Tables.Add(data);
        return ds;
    }

    private void ExporttoFile(MemoryStream ms, string filename)
    {
        HttpContext.Current.Response.Clear();
        HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=\"" + filename + ".xlsx" + "\"");
        HttpContext.Current.Response.BinaryWrite(ms.ToArray());
        HttpContext.Current.Response.Flush();
        HttpContext.Current.Response.End();
    }

    private void ClearAll()
    {
        lblError.Text = "";
    }

    private void BindGrid()
    {
        gvEmployee.DataSource = GetDataset();
        gvEmployee.DataBind();
    }

    #endregion
}