/*
Template Name: Corlate
Author: WpFreeware
Author URI: http://wpfreeware.com/
Description: Ultra Responsive Bootstrap Educational Html5 Template.
Version: 1.0
Tags: light, white,Multi page,Education,School, University,custom-colors,Bootstrap,responsive, html5, css3
License: GPL V3 or later
License URI: http://www.gnu.org/licenses/gpl.html
*/


---------------------------------------------
WpFreeware.com // Resource license terms
---------------------------------------------

You are not limited to use our resources. No hidden policies or rules. But a link back to us will be highly appreciated!. 
All of our resources are licensed under GNU General Public License V3 or later..
 
Read GPL license : http://www.gnu.org/licenses/gpl.html
 
———————————————
Find more great resources @ WpFreeware.com
Sincerely,
The WpFreeware Team.
———————————————
Thank you!
